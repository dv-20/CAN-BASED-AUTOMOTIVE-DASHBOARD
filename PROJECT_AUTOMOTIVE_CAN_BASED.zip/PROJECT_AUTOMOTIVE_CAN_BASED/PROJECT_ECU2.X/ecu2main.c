
/*Title: CAN Based Automotive Dashboard
 Author : Divyansu Sarkar 
 *        Shamitha Sujith 
 *        Thushar Karkera 
 * Description : This project involves designing and implementing an automotive dashboard that communicates with 
 * a vehicle's Electronic Control Units (ECUs) via the Controller Area Network (CAN) bus.
 * The dashboard displays real-time vehicle data such as speed, RPM, Turn Light,Gear Position and engine temperature, 
 * enhancing driver awareness and diagnostics.It utilizes a microcontroller with CAN support to read and 
 * interpret CAN messages and update a digital display accordingly.
 */
#include <xc.h>
#include "ecu2_sensor.h"
#include "clcd.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include <string.h>

uint16_t get_rpm() {
    uint16_t adc_reg_val = read_adc(RPM_ADC_CHANNEL);

    if ((adc_reg_val * 6.9) < 1500) {
        return 1500;
    }
    if((adc_reg_val * 6.9) > 7000)
        return 7000;
    return (adc_reg_val * 6.9);

}
char signal[2] = "F";

IndicatorStatus process_indicator() {
    static unsigned char key;
    key = read_keypad();
    if (key == DKP_SW1) {


        RB0 = 1;
        RB1 = 1;
        RB6 = 0;
        RB7 = 0;
        signal[0] = 'L';

        return e_ind_left;


    } else if (key == DKP_SW2) {

        RB6 = 1;
        RB7 = 1;
        RB0 = 0;
        RB1 = 0;
        signal[0] = 'R';

        return e_ind_right;
    } else if (key == DKP_SW3) {

        RB6 = 0;
        RB7 = 0;
        RB0 = 0;
        RB1 = 0;
        signal[0] = 'F';
        return e_ind_off;
    }
    return key;
}

static void init_config() {
    init_can();
    init_adc();
    TRISC |= 0x0F;

    TRISB7=0;
    TRISB6=0;
    TRISB1=0;
    TRISB0=0;
    PORTB=0x00;


}

void reverse(char *str) {
    int i = 0;
    char temp;
    int len = strlen(str);
    while (i < len / 2) {
        temp = str[i];
        str[i] = str[len - 1 - i];
        str[len - 1 - i] = temp;
        i++;
    }
}

void ITOA(unsigned int data, char *str) {
    int i = 0;
    char temp;
    if (data < 10) {
        str[0] = data + '0';
        str[1] = 0;
        return;
    }
    while (data) {
        temp = data % 10;
        data = data / 10;
        str[i++] = temp + '0';
    }
    str[i] = '\0';
    reverse(str);

}

void main() {

    init_config(); //Configuring the pheripherals
    char rpm_char[6] = {0};

    unsigned int rpm = 0;
    int delay = 0;

    while (1) {


        rpm = get_rpm();
        ITOA(rpm, rpm_char);
        if (delay % 50 == 0)
            can_transmit(RPM_MSG_ID, rpm_char, strlen(rpm_char) + 1);

        process_indicator();
        if (delay % 190 == 0) {
            can_transmit(INDICATOR_MSG_ID, signal, 1 + 1);
            delay = 0;
        }
        delay++;
    }
}
