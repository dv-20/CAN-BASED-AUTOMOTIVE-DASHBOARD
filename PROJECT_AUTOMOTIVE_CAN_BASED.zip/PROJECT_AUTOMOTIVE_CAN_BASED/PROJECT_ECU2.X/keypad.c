/*
 * File:   keypad.c
 * Author: divya
 *
 * Created on 14 April, 2025, 8:42 AM
 */


#include <xc.h>
char flag=1;
char read_keypad()
{
    if((PORTC&0x0F) !=0x0F && flag)
    {
        flag=0;
        return PORTC&0x0F;
    }
    else if((PORTC&0x0F) ==0x0F)
    {
        flag=1;
    }
    return 0x0F;
}