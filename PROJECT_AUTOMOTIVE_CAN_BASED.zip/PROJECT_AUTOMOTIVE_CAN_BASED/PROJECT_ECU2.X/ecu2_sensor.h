/* 
 * File:   ecu2_sensor.h
 * Author: divya
 *
 * Created on 21 April, 2025, 8:14 AM
 */

#ifndef ECU2_SENSOR_H
#define	ECU2_SENSOR_H

#include <stdint.h>
//#include "matrix_keypad.h"

#define RPM_ADC_CHANNEL 0x04


#define LED_OFF 0
#define LED_ON 1
#define DKP_SW1 0x0E
#define DKP_SW2 0x0D
#define DKP_SW3 0x0B

#define RIGHT_IND_ON() (PORTB = PORTB | 0xC0)
#define RIGHT_IND_OFF() (PORTB = PORTB & ~0xC0)
#define LEFT_IND_ON() (PORTB = PORTB | 0x03)
#define LEFT_IND_OFF() (PORTB = PORTB & ~0x03)

typedef enum {
    e_ind_off,
    e_ind_left,
    e_ind_right
} IndicatorStatus;

extern volatile IndicatorStatus prev_ind_status, cur_ind_status;
extern volatile unsigned char led_state;

uint16_t get_rpm();
IndicatorStatus process_indicator();
char read_keypad();

#endif	/* ECU1_SENSOR_H */
