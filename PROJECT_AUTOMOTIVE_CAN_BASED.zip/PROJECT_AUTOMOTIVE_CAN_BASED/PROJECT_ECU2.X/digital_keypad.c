/*
 * File:   digital_keypad.c
 * Author: divya
 *
 * Created on 21 April, 2025, 4:37 PM
 */


#include <xc.h>

char flag=1;

unsigned char read_keypad(unsigned state)
{
    if(state==STATE)
}