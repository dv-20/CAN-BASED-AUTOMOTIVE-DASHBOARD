
/*Title: CAN Based Automotive Dashboard
 Author : Divyansu Sarkar 
 *        Shamitha Sujith 
 *        Thushar Karkera 
 * Description : This project involves designing and implementing an automotive dashboard that communicates with 
 * a vehicle's Electronic Control Units (ECUs) via the Controller Area Network (CAN) bus.
 * The dashboard displays real-time vehicle data such as speed, RPM, Turn Light,Gear Position and engine temperature, 
 * enhancing driver awareness and diagnostics.It utilizes a microcontroller with CAN support to read and 
 * interpret CAN messages and update a digital display accordingly.
 */
        


#include <xc.h>
#include "ecu1_sensor.h"
#include "clcd.h"
#include "adc.h"
#include "can.h"
#include "matrix_keypad.h"
#include "msg_id.h"
#include <string.h>

uint16_t get_speed() {
    uint16_t adc_reg_val = read_adc(SPEED_ADC_CHANNEL);

    return (adc_reg_val / 10.33);

}

unsigned char get_gear_pos() {
    static unsigned char gear_pos;

    char key = read_switches(STATE_CHANGE);

    if (key == GEAR_UP) {
        if (gear_pos < MAX_GEAR)
            gear_pos++;
        else
            gear_pos = 7;

    } else if (key == GEAR_DOWN) {
        if (gear_pos > 1)
            gear_pos--;
        else
            gear_pos = 0;
    } else if (key == COLLISION) {
        gear_pos = 8;
    }
    if (gear_pos == 0)
        return 'N';
    else if (gear_pos == 7)
        return 'R';
    else
        return gear_pos + '0';

}

uint16_t get_engine_temp() {
    uint16_t adc_reg_val = read_adc(ENG_TEMP_ADC_CHANNEL);

    return ((adc_reg_val * ((float) 5 / 1023)) * 100);
    //return adc_reg_val/10.1;
}

static void init_config() {
    init_can();
    init_adc();
   // init_clcd();
    init_matrix_keypad();

}

void reverse(char *str) {
    int i = 0;
    char temp;
    int len = strlen(str);
    while (i < len / 2) {
        temp = str[i];
        str[i] = str[len - 1 - i];
        str[len - 1 - i] = temp;
        i++;
    }
}

void ITOA(unsigned short data, char *str) {
    int i = 0;
    char temp;
    if (data < 10) {
        str[0] = data + '0';
        str[1] = 0;
        return;
    }
    while (data) {
        temp = data % 10;
        data = data / 10;
        str[i++] = temp + '0';
    }
    str[i] = '\0';
    reverse(str);

}

void main() {
    init_config(); //Configuring the pheripherals
    
    char speed_char[8] = "0000000";
    char temp_char[8] = "0000000";
    unsigned char gear_pos[2] = "0";
    int delay1 = 0;
    int delay2 = 0, delay3 = 0;
    
    while (1) {
        //Have to get speed and transmit to ECU3
        if (!delay1--) {
            delay1 = 300;
            uint16_t speed = get_speed();
            ITOA(speed, speed_char);
            can_transmit(SPEED_MSG_ID, speed_char, strlen(speed_char) + 1);
        }


        //Have to get gear position and transmit to ECU3
        gear_pos[0] = get_gear_pos();

        //Have to get temparature and transmit to ECU3
        if (!delay2--) {
            delay2 = 500;
            uint16_t engine_temp = get_engine_temp();
            ITOA(engine_temp, temp_char);
            can_transmit(ENG_TEMP_MSG_ID, temp_char, strlen(temp_char) + 1);
        }

        if (!delay3--) {
            delay3 = 200;
            can_transmit(GEAR_MSG_ID, gear_pos, 1 + 1);
        }


    }
}
