
/*Title: CAN Based Automotive Dashboard
 Author : Divyansu Sarkar 
 *        Shamitha Sujith 
 *        Thushar Karkera 
 * Description : This project involves designing and implementing an automotive dashboard that communicates with 
 * a vehicle's Electronic Control Units (ECUs) via the Controller Area Network (CAN) bus.
 * The dashboard displays real-time vehicle data such as speed, RPM, Turn Light,Gear Position and engine temperature, 
 * enhancing driver awareness and diagnostics.It utilizes a microcontroller with CAN support to read and 
 * interpret CAN messages and update a digital display accordingly.
 */


#include <xc.h>
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include "message_handler.h"
extern unsigned char can_payload[13];
//void reverse(char *str);

void init_config() {
    
    init_clcd();
    init_can();
    TRISB7=0;
    TRISB6=0;
    TRISB1=0;
    TRISB0=0;
    PORTB=0x00;
    //TRISB=0X00;
    

}

void main(void) {
    init_config();

    char speed[3] = "00";
    char gear[2] = "0";
    char engine[3] = "00";
    char rpm[6] = "00000";
    char indicator[2] = "0";
    char flag=0;
    int delay=0;

    while (1) {
        clcd_print("SP GR TMP S RPM ", LINE1(0));
        //clcd_print("SPEED  GEAR  TEMP",LINE1(0));
    if(delay<100)
    {
       if(flag==1)
       {
        RB0=1;
        RB1=1;
        RB7=0;
        RB6=0;
       }
       else if(flag==2)
       {
        RB7=1;
        RB6=1;
        RB1=0;
        RB0=0;
       }
    }
    else if(delay>100 && delay<200)
    {
        RB1=0;
        RB0=0;
        RB7=0;
        RB6=0;
    }
    else
        delay=0;
     delay++;
        if (can_receive()) {

            switch (can_payload[SIDH]) {
                case SPEED_MSG_ID:
                    handle_speed_data(speed, can_payload[DLC] - 1);
                    clcd_print(speed, LINE2(0));
                    break;
                case GEAR_MSG_ID:
                    //handle_gear_data(gear, can_payload[DLC]-1);
                    if (can_payload[D0] == '8' && can_payload[DLC]==2) {
                        clcd_print("  !!COLLISION!!  ", LINE2(0));
                        exit(0);
                    }
                    clcd_putch(can_payload[D0], LINE2(3));
                    break;
                case RPM_MSG_ID:
                    handle_rpm_data(rpm, can_payload[DLC]);
                    clcd_print(rpm, LINE2(12));
                    break;
                case ENG_TEMP_MSG_ID:
                    handle_engine_temp_data(engine, can_payload[DLC] - 1);
                    clcd_print(engine, LINE2(6));
                    clcd_putch('C', LINE2(8));
                    break;
                case INDICATOR_MSG_ID:
                     if(can_payload[D0]=='L')
                    {
                      //PORTB=(PORTB&0x00)|0x0F;
                      
                      RB0=1;
                      RB1=1;
                      RB7=0;
                      RB6=0;
                      flag=1;
                    }
                    else if(can_payload[D0]=='R')
                    {
                      //PORTB=(PORTB&0x00)|0xF0;
                      //PORTB|=0x03;
                      RB0=0;
                      RB1=0;
                      RB7=1;
                      RB6=1;
                      flag=2;
                    }
                    else if(can_payload[D0]=='F')
                    {
                      //PORTB=(PORTB&0x00)|0x00;
                      //PORTB&=0xF0;
                      RB1=0;
                      RB0=0;
                      RB7=0;
                      RB6=0;
                      flag=0;
                    }
                    clcd_putch(can_payload[D0], LINE2(10));
                    break;
                  }
                    
            }
        }
}

void handle_speed_data(uint8_t *data, uint8_t len) {
    int i;

    //clcd_putch(len+'0',LINE2(5));
    for (i = 0; i < len; i++) {
        data[i] = can_payload[D0 + i];
    }
    data[i] = '\0';
}

void handle_gear_data(uint8_t *data, uint8_t len) {

    int i;
    //clcd_putch(len+'0',LINE2(5));
    for (i = 0; i < len; i++) {
        data[i] = can_payload[D0 + i];
    }
    data[i] = '\0';
}

void handle_rpm_data(uint8_t *data, uint8_t len) {
    int i;
    for (i = 0; i < len; i++) {
        data[i] = can_payload[D0 + i];
    }
    data[i] = '\0';
}

void handle_engine_temp_data(uint8_t *data, uint8_t len) {
    int i;
    //clcd_putch(len+'0',LINE2(5));
    for (i = 0; i < len; i++) {
        data[i] = can_payload[D0 + i];
    }
    data[i] = '\0';
}

void handle_indicator_data(uint8_t *data, uint8_t len) {

    int i;
    for (i = 0; i < len; i++) {
        data[i] = can_payload[D0 + i];
    }
    data[i] = '\0';
}
